// Copyright 2025-present 650 Industries. All rights reserved.

import ExpoModulesCore
import SwiftUI

internal final class AlertProps: UIBaseViewProps {
  @Field var title: String = ""
  @Field var isPresented: Bool = false
  var onIsPresentedChange = EventDispatcher()
}
